const { MongoClient, ObjectId } = require('mongodb');

process.env.MONGODB_URI = 'mongodb://se-fall2024-jenny:tJAZKBU3iOoTKCOvC1pNDfN23rSR0VSOYV3GvFL0wNJK4ou4aDEARW2Az5zM8nX5PTnWz0FPVQpRACDbAFme0w==@se-fall2024-jenny.mongo.cosmos.azure.com:10255/?ssl=true&retrywrites=false&replicaSet=globaldb&maxIdleTimeMS=120000&appName=@se-fall2024-jenny@';

if (!process.env.MONGODB_URI) {
    process.env.MONGODB_URI = 'mongodb://localhost:27017';
}

// Connect to MongoDB
async function connectToDB() {
    const client = await MongoClient.connect(process.env.MONGODB_URI);
    const db = client.db('rentingDB');
    db.client = client;
    return db;
}

module.exports = { connectToDB, ObjectId };