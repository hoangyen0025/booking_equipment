var express = require('express');
var router = express.Router();
//ObjectId obtain by Objectid in db.js
const { connectToDB, ObjectId } = require('../utils/db');
var { authenticate, isAdmin, isUser} = require("../utils/auth");


//authenticate, isAdmin : access by admin only 
router.post('/',authenticate, isAdmin, async function (req, res) {
  //async function: is invoked when this route is accessed.
  const db = await connectToDB(); //connectToDB function: establish a connection to the MongoDB (Cosmos) database.
  try {
    req.body.color = req.body.color || '#000000'; // Default to black if no color provided
    req.body.highlight = req.body.highlight? true : false;
    req.body.created_at = new Date();
    req.body.modified_at = new Date();

    let result = await db.collection("equipments").insertOne(req.body); 
    res.status(201).json({ id: result.insertedId });
  } catch (err) {
    res.status(400).json({ message: err.message });
  } finally {
    await db.client.close();
  }
});

  //display one equipment (detail)
router.get('/:id', async function (req, res) { 
    const db = await connectToDB();
    try {
      let result = await db.collection("equipments").findOne({ _id: new ObjectId(req.params.id) }); 
      
      if (result) { //if found 
        res.json({ equipment: result}); //pass to render method to render a template named edit.ejs
      } else { //if no 
        res.status(404).json({ message: "Equipment not found" }); //show error 404 
      }
    } catch (err) {//if any error 
      res.status(400).json({ message: err.message }); //-> show error 400 and error message 
    } finally {
      await db.client.close(); //close connection 
    }
});

router.put('/:id',authenticate, isAdmin, async function (req, res) {
  const db = await connectToDB();
  try {
    req.body.color = req.body.color || '#000000'; // Default to black if no color provided
      req.body.highlight = req.body.highlight? true : false;
      req.body.created_at = new Date();
      req.body.modified_at = new Date();
      delete req.body._id
      let result = await db.collection("equipments").updateOne({ _id: new ObjectId(req.params.id) }, { $set: req.body });

      if (result.modifiedCount > 0) {
          res.status(200).json({ message: "Equipment updated" });
      } else {
          res.status(404).json({ message: "Equipment not found" });
      }
  } catch (err) {
      res.status(400).json({ message: err.message });
  } finally {
      await db.client.close();
  }
});
router.delete('/:id', authenticate, isAdmin, async function (req, res) {
  const db = await connectToDB();
  try {
      let result = await db.collection("equipments").deleteOne({ _id: new ObjectId(req.params.id) });

      if (result.deletedCount > 0) {
          res.status(200).json({ message: "Equipment deleted" });
      } else {
          res.status(404).json({ message: "Equipment not found" });
      }
  } catch (err) {
      res.status(400).json({ message: err.message });
  } finally {
      await db.client.close();
  }
});
router.get('/', async function (req, res) {
  const db = await connectToDB();
  try {
      let query = {};
      if (req.query.name) {
          // query.email = req.query.email;
          query.name = { $regex: req.query.name };
      }
      let page = parseInt(req.query.page) || 1;
      let perPage = parseInt(req.query.perPage) || 6;
      let skip = (page - 1) * perPage;

      let result = await db.collection("equipments").find(query).skip(skip).limit(perPage).toArray();
      let total = await db.collection("equipments").countDocuments(query); //this "total" is the total number of bookings that meet the search criteria
     //res.render (from prev labs) is replaced with res.json because RESTful API returns JSON data 
      res.json({ equipments: result, total: total, page: page, perPage: perPage });
  } catch (err) {
      res.status(400).json({ message: err.message });
  }
 finally {
      await db.client.close();
  }
});


//Rent an equipment by ID
router.post('/:id/rent', authenticate, isUser, async function (req, res) {
    const db = await connectToDB();
      try {
        //find id and 
        //startTime: {"$lte": req.body.endDate}: the query retrieves all events that start on or before the specified endDate.
        await db.collection("equipments").findOne({ _id: new ObjectId(req.params.id), startTime: {"$lte": req.body.endDate}});
          let result = await db.collection("equipments").updateOne({ _id: new ObjectId(req.params.id) },
              {
                  //adds the specified value to the rent array to the dtb with rent array
                  $addToSet: {rent: {id: new ObjectId(req.user._id), name: req.user.name, startTime: new Date(req.body.startTime), returnTime: new Date(req.body.returnTime)}}
              });
          if (result.modifiedCount > 0) {
              res.status(200).json({ message: "Equipment updated" });
          } else {
              res.status(404).json({ message: "Equipment not found" });
          }
      } catch (err) {
        res.status(500).json({ message: err.message });
    }
    finally {
        await db.client.close();
    }
});

module.exports = router;