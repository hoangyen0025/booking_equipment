const express = require('express');
const router = express.Router();
const { connectToDB, ObjectId } = require('../utils/db');
var { authenticate, isAdmin, isUser} = require("../utils/auth");
// /* GET users listing. */
// router.get('/', function(req, res, next) {
//   res.send('respond with a resource');
// });
//display all the users 
// router.get('/', async function (req, res) {
//   const db = await connectToDB();
//   try {
//       let results = await db.collection("users").find().toArray();
//       res.json({ users: results });
//   } catch (err) {
//       res.status(400).json({ message: err.message });
//   } finally {
//       await db.client.close();
//   }
// });
//add user 
router.post('/',authenticate, isAdmin, async function (req, res) {
  //async function: is invoked when this route is accessed.
  const db = await connectToDB(); //connectToDB function: establish a connection to the MongoDB (Cosmos) database.
  try {
    req.body.contactNumber = parseInt(req.body.contactNumber);
    req.body.terms = req.body.terms? true : false;
    req.body.created_at = new Date();
    req.body.modified_at = new Date();

    let result = await db.collection("users").insertOne(req.body); 
    res.status(201).json({ id: result.insertedId });
  } catch (err) {
    res.status(400).json({ message: err.message });
  } finally {
    await db.client.close();
  }
});
//get user by id and Retrieving Users and their Bookings
router.get('/:id', async function (req, res) { 
  const db = await connectToDB();
  try {
    //find id
    let result = await db.collection("users").findOne({ _id: new ObjectId(req.params.id) }); 
    ///finding rented equipment of the id
    let equipments = await db.collection("equipments").aggregate([
      {$unwind: "$rent"}, //deconstruct the "rent" array, creating a document for each element in the array.
      {$match: {"rent.id": new ObjectId(req.params.id)}}, //rent.id (user who rent the equipment) matches the user ID 
    ]).toArray();

    if (result) { //if found 
      res.json({ users: result,equipments:equipments }); //pass to render method to render a template named edit.ejs
    } else { //if no 
      res.status(404).json({ message: "User not found" }); //show error 404 
    }
  } catch (err) {//if any error 
    res.status(400).json({ message: err.message }); //-> show error 400 and error message 
  } finally {
    await db.client.close(); //close connection 
  }
});

router.put('/:id', async function (req, res) {
  const db = await connectToDB();
  try {
    req.body.contactNumber = parseInt(req.body.contactNumber);
    req.body.terms = req.body.terms? true : false;
    req.body.created_at = new Date();
    req.body.modified_at = new Date();
      delete req.body._id
      let result = await db.collection("users").updateOne({ _id: new ObjectId(req.params.id) }, { $set: req.body });

      if (result.modifiedCount > 0) {
          res.status(200).json({ message: "Users updated" });
      } else {
          res.status(404).json({ message: "User not found" });
      }
  } catch (err) {
      res.status(400).json({ message: err.message });
  } finally {
      await db.client.close();
  }
});
router.delete('/:id', async function (req, res) {
  const db = await connectToDB();
  try {
      let result = await db.collection("users").deleteOne({ _id: new ObjectId(req.params.id) });

      if (result.deletedCount > 0) {
          res.status(200).json({ message: "User deleted" });
      } else {
          res.status(404).json({ message: "User not found" });
      }
  } catch (err) {
      res.status(400).json({ message: err.message });
  } finally {
      await db.client.close();
  }
});

//show users, pagination, search
router.get('/',authenticate, isAdmin, async function (req, res) {
  const db = await connectToDB();
  try {
      let query = {};
      if (req.query.name) {
          // query.email = req.query.email;
          query.name = { $regex: req.query.name };
      }
      // if (req.query.numTickets) {
      //     query.numTickets = parseInt(req.query.numTickets);
      // }

      let page = parseInt(req.query.page) || 1;
      let perPage = parseInt(req.query.perPage) || 8;
      let skip = (page - 1) * perPage;

      let result = await db.collection("users").find(query).skip(skip).limit(perPage).toArray();
      let total = await db.collection("users").countDocuments(query); //this "total" is the total number of bookings that meet the search criteria
     //res.render (from prev labs) is replaced with res.json because RESTful API returns JSON data 
      res.json({ users: result, total: total, page: page, perPage: perPage });
  } catch (err) {
      res.status(400).json({ message: err.message });
  }
 finally {
      await db.client.close();
  }
});

module.exports = router;
