
const express = require('express');
const router = express.Router();
const { connectToDB, ObjectId } = require('../utils/db');
const { generateToken, extractToken, removeToken, verifyToken } = require('../utils/auth');
var { authenticate, isAdmin, isUser} = require("../utils/auth");

//handle login request
router.post('/api/login', async function (req, res) {
  const db = await connectToDB();
  try {
    // check if the user exists
    var user = await db.collection("users").findOne({ email: req.body.email });
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }
    // return a JWT token
    res.json({ token: await generateToken(user) });
    
  } catch (err) {
    res.status(500).json({ message: err.message });
  } finally {
    await db.client.close();
  }
});
//logout
router.post('/api/logout', async function (req, res) {
  const token = extractToken(req);

  if (!token) {
      return res.status(400).json({ message: "Bad Request: No token provided" }); // Handle missing token
  }

  try {
      await removeToken(token); // Attempt to remove the token
      res.status(204).send(); // No content response for successful logout
  } catch (err) {
      console.error("Error during logout:", err); // Log any errors
      res.status(500).json({ message: "Internal Server Error" }); // Handle server errors
  }
});
router.get('/test', verifyToken, function (req, res, next) {
  console.log(req.user)
  res.send('respond with a resource');
});
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

// //get the equipment page 
//  router.get('/equipments', async function (req, res) {
//    res.render('equipments');
//  });

/* GET the equipment add page. */
router.get('/equipment/add', async function (req, res) {
  res.render('add');
});


/* Handle the Form */
/* This route handler will be triggered whenever a client visits the path /equipment/add */
router.post('/equipment/add', async function (req, res) {
  //async function: is invoked when this route is accessed.
  const db = await connectToDB(); //connectToDB function: establish a connection to the MongoDB (Cosmos) database.
  try {
    req.body.color = req.body.color || '#000000'; // Default to black if no color provided
    req.body.highlight = req.body.highlight? true : false;
    req.body.created_at = new Date();
    req.body.modified_at = new Date();

    let result = await db.collection("equipments").insertOne(req.body); 
    res.status(201).json({ id: result.insertedId });
  } catch (err) {
    res.status(400).json({ message: err.message });
  } finally {
    await db.client.close();
  }
});
//display all the booking 
router.get('/equipments', async function (req, res) {
  const db = await connectToDB();
  try {
      let results = await db.collection("equipments").find().toArray();
      res.render('equipments', { equipments: results });
      const highlightedEvents = results
      .filter((equipments) => equipments.highlight === true)
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 3);

    res.json({ equipments: results, total: total, page: page, perPage: perPage, highlightedEvents: highlightedEvents });
  } catch (err) {
      res.status(400).json({ message: err.message });
  } finally {
      await db.client.close();
  }
});
module.exports = router;

//display one equipment
router.get('/equipment/edit/:id', async function (req, res) { 
  const db = await connectToDB();
  try {
    let result = await db.collection("equipments").findOne({ _id: new ObjectId(req.params.id) }); 
    if (result) { //if found 
      res.render('edit', { equipment: result }); //pass to render method to render a template named edit.ejs
    } else { //if no 
      res.status(404).json({ message: "Equipment not found" }); //show error 404 
    }
  } catch (err) {//if any error 
    res.status(400).json({ message: err.message }); //-> show error 400 and error message 
  } finally {
    await db.client.close(); //close connection 
  }
});

// Delete a single equipment
router.post('/equipment/delete/:id', async function (req, res) {  //async function: invoked when this route is accessed 
  const db = await connectToDB(); //connect to mongodb 
  try {
    let result = await db.collection("equipments").deleteOne({ _id: new ObjectId(req.params.id) }); //use deleteone method
    if (result.deletedCount > 0) { //deletedCount property: hold the numbers of deleted documents. By checking this value, can know whether a document is successfully deleted or not 
      res.status(200).json({ message: "Equipment deleted" });
      //alert("Deleted successfully!");
    } else {
      res.status(404).json({ message: "Equipment not found" });
    }
  } catch (err) {
    res.status(400).json({ message: err.message });
  } finally {
    await db.client.close();
  }
});

/////////
//UPDATE A SINGLE BOOKING
router.post('/equipment/edit/:id',authenticate, isAdmin, async function (req, res) {
  const db = await connectToDB();
  try {
    req.body.location = req.body.location || "";
    req.body.highlight = req.body.highlight? true : false;
    req.body.modified_at = new Date();

    let result = await db.collection("equipments").updateOne({ _id: new ObjectId(req.params.id) }, { $set: req.body });

    if (result.modifiedCount > 0) {
      res.status(200).json({ message: "Equipment updated" });
    } else {
      res.status(404).json({ message: "Equipment not found" });
    }
  } catch (err) {
    res.status(400).json({ message: err.message });
  } finally {
    await db.client.close();
  }
});

//display one equipment
router.get('/equipment/detail/:id', async function (req, res) { 
  const db = await connectToDB();
  try {
    let result = await db.collection("equipments").findOne({ _id: new ObjectId(req.params.id) }); 
    if (result) { //if found 
      res.render('detail', { equipment: result }); //pass to render method to render a template named edit.ejs
    } else { //if no 
      res.status(404).json({ message: "Equipment not found" }); //show error 404 
    }
  } catch (err) {//if any error 
    res.status(400).json({ message: err.message }); //-> show error 400 and error message 
  } finally {
    await db.client.close(); //close connection 
  }
});
module.exports = router;