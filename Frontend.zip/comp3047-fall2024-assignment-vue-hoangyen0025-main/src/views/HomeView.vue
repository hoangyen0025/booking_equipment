<script setup>
import {onMounted, ref} from "vue";
//import TheWelcome from '../components/TheWelcome.vue'
import { CalendarView, CalendarViewHeader } from "vue-simple-calendar"

import "../../node_modules/vue-simple-calendar/dist/style.css"
// The next two lines are optional themes
import "../../node_modules/vue-simple-calendar/dist/css/default.css"
import "../../node_modules/vue-simple-calendar/dist/css/holidays-us.css"
const equipments = ref([]);
const hl = ref([]);
const items = ref([]);
const showDate=ref(new Date())
const setShowDate =function(d)
{
  showDate.value = d;
}
///check again 
const showRentalDate = async() => {
  try {
    const token = localStorage.getItem('token');
    const response = await fetch('/api/equipments', {
      headers: {
                Authorization: `Bearer ${token}`, //use the token here
              },
  });
    // convert the response to json

  const json = await response.json();
  const equipmentData = json.equipments; 
  equipments.value = json.equipments;
  //a: ... 
  ///b: is the equipment data
  items.value =  json.equipments.reduce((a, b) => {
     //alert(JSON.stringify(b))
    if (b.rent && b.rent.length > 0){
      return a.concat(b.rent.map((it) => ({
        //it.title = b.name,
        id: b._id,
        startDate: new Date(it.startTime),
        returnDate: new Date(it.returnTime),
        title: `${b.name} @ ${b.location}`,
        //return it
      }))
    );
  }
  return a;
 },[]);
  //alert(JSON.stringify(items.value))

  //alert(JSON.stringify(equipmentData));
  const events = equipmentData.flatMap(equipment => {
    if (equipment && Array.isArray(equipment.rent)){
      return equipment.rent.map(rent => ({
        id: equipment.id,
        startDate: new Date(rent.startTime),
        endDate: new Date(rent.returnTime),
        title: `${equipment.name} @ ${equipment.location}`,
        style: 'background-color: pink; colour: blue; text-align: center',
      }));
    }
    else{
      console.warn('Invalid or misssing rent data');
      return[];
    }
    });
    items.value=events;
    //alert(JSON.stringify(items.value))
  }
  catch(error){
    alert(error);
  }
}
onMounted(async () => {
showRentalDate();
})
</script>

<template>
<!-- the highlight not work  -->
  <div class="container-fluid my-4">
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="https://picsum.photos/200/50" class="d-block w-100 img-fluid" alt="projector">
        </div>
        <div class="carousel-item">
          <img src="https://picsum.photos/200/51" class="d-block w-100 img-fluid" alt="mouse">
        </div>
        <div class="carousel-item">
          <img src="https://picsum.photos/200/52" class="d-block w-100 img-fluid" alt="HDMI to USB converter">
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
        data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
        data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
    </div>


  
<!-- <div class="container-fluid my-4">
    <nav aria-label="Page navigation example">
      <ul class="pagination">
        <li class="page-item"><a class="page-link" href="#" onclick="navigateMonth('prev')">Previous</a></li>
        <li class="page-item"><a class="page-link" href="#" onclick="buttonClicked('Sep', this)">Sep</a></li>
        <li class="page-item"><a class="page-link" href="#" onclick="buttonClicked('Oct', this)">Oct</a></li>
        <li class="page-item"><a class="page-link" href="#" onclick="buttonClicked('Nov', this)">Nov</a></li>
        <li class="page-item"><a class="page-link" href="#" onclick="navigateMonth('next')">Next</a></li>
      </ul>
    </nav>
</div> -->

  <button></button>

  <div class="container-fluid my-4">
    <table class="table table-bordered" id="table"></table>
  </div>

  <div id="app2">
    <h1>My Calendar</h1>
    <CalendarView
        :show-date="showDate" :items="items"
        class="theme-default holiday-us-traditional holiday-us-official">
        <template #header="{ headerProps }">
            <CalendarViewHeader
                @input="setShowDate" :headerProps="headerProps" />
        </template>
    </CalendarView>
</div>

</template>
<style>
  #app2 {
		font-family: 'Avenir', Helvetica, Arial, sans-serif;
		color: #2c3e50;
		height: 67vh;
		width: 90vw;
		margin-left: auto;
		margin-right: auto;
	}
</style>