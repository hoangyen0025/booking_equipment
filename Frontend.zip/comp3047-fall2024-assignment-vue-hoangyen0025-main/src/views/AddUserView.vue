<script setup>
import { ref, onMounted, computed, watch } from 'vue'

const users = ref({
    email: '',
    password: '',
    name: '',
    contactNumber: '',
    department: '',
    remark: '',
    terms: false,
});

const submitUser = async function() {
  const token = localStorage.getItem('token');
  // post the booking to the backend
  const response = await fetch('/api/users', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,  //use the token here
      },
      body: JSON.stringify(users.value)
  });
  // convert the response to json
  const json = await response.json();
  // log the json
  console.log(json);
  // alert the user
  alert(JSON.stringify(json));
  router.push('/users');
}
</script>
<template>
  <div class="container-fluid my-3" style="padding-top:20px; padding-left:30px;">
    <div class="d-flex justify-content-between align-items-center">
      <h5 href="/equipments" class="text-primary">User <span class="text-secondary"> / New</span></h5>
    </div>
  </div>
    <form class="row mb-3 ms-3" v-on:submit.prevent="submitUser" >
    <div class="col-12 mb-3">
        <label for="exampleInputEmail1" class="form-label">Email</label>
        <input type="email" class="form-control" id="exampleInputEmail1" v-model="users.email" style="width: 50%;">
    </div>
    <div class="col-12 mb-3">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <input type="password" class="form-control" id="exampleInputPassword1" v-model="users.password" style="width: 50%;">
    </div>
    <div class="col-12 mb-3">
        <label for="inputName" class="form-label">Name</label>
        <input type="text" class="form-control" id="exampleName" v-model="users.name" style="width: 50%;">
    </div>
    <div class="col-12 mb-3">
        <label for="inputContactNumber" class="form-label">Contact number</label>
        <input type="text" class="form-control" id="exampleContactNumber" v-model="users.contactNumber" style="width: 50%;">
    </div>
    <div class="col-12 mb-3">
        <label for="inputDepartment" class="form-label">Department</label>
        <select class="form-select" aria-label="Default select example" v-model="users.department" style="width: 50%;">
          <option value="" selected>Dropdown...</option>
          <option value="Computer Science">Computer Science</option>
          <option value="Mathematics">Mathematics</option>
          <option value="Physics">Physics</option>
      </select>
      </div>

      <div class="col-12 mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Remark</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"  v-model="users.remark" style="width: 50%;"></textarea>
        </div>

        <div class="col-12 mb-3">
        <div class="col-sm-10">
          <div class="form-check">
            <input
              class="form-check-input"
              type="checkbox"
              id="gridCheck1"
              v-model="users.terms"
            />
            <label class="form-check-label" for="gridCheck1">
              Is administrator?
            </label>
          </div>
        </div>
      </div>
      <div class="col-12 mb-3">
        <button type="submit" class="btn btn-primary">Save</button>
    </div>
</form>
</template>