<script setup>
import { ref, onMounted, computed, watch } from 'vue';
import { useRoute } from "vue-router";
import { jwtDecode } from "jwt-decode";
const router = useRoute(); // get id 
const equipments = ref([]); //////


const rangeBefore = ref(3);
const rangeAfter = ref(1);
const isSimple = ref(false);
const isRounded = ref(false);
const prevIcon = ref("chevron-left");
const nextIcon = ref("chevron-right");
const total = ref(200);
const current = ref(1);
const perPage = ref(6);
const order = ref("left");
const size = ref("");
const loading = ref(false);
const page = ref(1);

const users = ref({});
const token = ref('');

//send current value to loadAsyncData
watch(() => current.value, () => {
    loadAsyncData();
})
const loadAsyncData = () => {
  try{
    const params = [
        // "api_key=bb6f51bef07465653c3e553d6ab161a8",
        // "language=en-US",
        // "include_adult=false",
        // "include_video=false",
        // `sort_by=${sortField.value}.${sortOrder.value}`,
        `page=${current.value}`,
    ].join("&");
    loading.value = true;
    // Get the token from local storage    
    const token = localStorage.getItem('token');
    //decode the jtw token 
    //decoded.value = jwtDecode(token);

    fetch(`/api/equipments?${params}`,{
            headers: {
                    Authorization: `Bearer ${token}`, //use the token here
                }
        })
        .then((response) => response.json())
        .then((result) => {
            perPage.value = result.perPage;
            total.value = result.total;
            equipments.value = result.equipments

            loading.value = false;
        });
}
    catch(error) {
        console.error('A problem with the fetch operation:', error);
        loading.value = false; 
    }
};
// * Handle page-change event
//  */
const onPageChange = (p) => {
    page.value = p;
    loadAsyncData();
};


//////
onMounted(()=> {
    loadAsyncData();
    token.value = localStorage.getItem("token");
    if (token.value){
      users.value = jwtDecode(token.value); //check if user or admin
    }
});


</script>
<template>
    <div class="container-fluid my-5" style="padding-top: 20px">
    <div class="d-flex justify-content-between align-items-center">
      <h5 class="text-primary">Equipments<span class="text-secondary"> /</span></h5>
      <!-- <button type="button" class="btn btn-primary" onclick="buttonClicked(this)">Add</button> -->
       <!-- v-if ="users.terms" : admin only  -->
      <a href="/equipment/add" class="btn btn-primary" v-if ="users.terms" >Add</a>
    </div>
  </div>
    <!-- ITEM LISTS  -->
    <div class="container-fluid my-4" @page-change="onPageChange" @sort="onSort">
    <div class="row mb-3">
        <div class="col-md-4 mb-4" v-for="eq in equipments" :key="eq._id">
          <div class="card h-100">
            <a :href="`/equipment/detail/${eq._id}`">
              <img v-bind:src="eq.image" class="card-img-top" alt="">
            </a>

            <div class="card-body d-flex flex-column">
              <h5 class="card-title">{{ eq.name }}@{{ eq.location }}</h5>
              <p class="card-text">{{ eq.description }}</p>
              <div class="mt-auto text-end">
              <a :href="`equipment/edit/${eq._id}`" class="btn btn-outline-primary px-4 py-2" v-if="users.terms">Edit</a>
              </div>
            </div>
          </div>
        </div>

    </div>
  </div>
  <o-pagination
        v-model:current="current"
        :total="total"
        :range-before="rangeBefore || 0"
        :range-after="rangeAfter || 0"
        :order="order"
        :size="size"
        :simple="isSimple"
        :rounded="isRounded"
        :per-page="perPage"
        :icon-prev="prevIcon"
        :icon-next="nextIcon" />

</template>