<script setup>
import { ref, onMounted, computed, watch } from 'vue';
import { useRoute, useRouter } from "vue-router";
import { jwtDecode } from "jwt-decode";
const route = useRoute(); // get id 
const router = useRouter(); //transfer a page 
const equipments=ref([]);
const users = ref({
    email: '',
    password: '',
    name: '',
    contactNumber: '',
    department: '',
    remark: '',
    terms: false,
    rent: []
});
const total = ref(0);
const loading = ref(false);
const sortField = ref("vote_count");
const sortOrder = ref("desc");
const defaultSortOrder = ref("desc");
const page = ref(1);
const perPage = ref(8);

const loadAsyncData = () => {
    try{
        const params = [
            // "api_key=bb6f51bef07465653c3e553d6ab161a8",
            // "language=en-US",
            // "include_adult=false",
            // "include_video=false",
            // `sort_by=${sortField.value}.${sortOrder.value}`,
            `page=${page.value}`,
        ].join("&");
        // Get the token from local storage    
        const token = localStorage.getItem('token');
        //decode the jtw token 
        const decoded = jwtDecode(token);
        console.log(decoded);
        name.value = `${decoded.first_name} ${decoded.last_name}`;
        fetch(`/api/users?${params}`,{
            headers: {
                    Authorization: `Bearer ${token}`,
                }
        })
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then((result) => {
            perPage.value = result.perPage;
            total.value = result.total;
            users.value = result.users;

            loading.value = false;
        })
    }
    catch(error) {
        console.error('A problem with the fetch operation:', error);
        loading.value = false; 
    }
};
const submitUsers = async function () {
    var url = '/api/users';
    var method = 'POST';
    // post the booking to the backend
        if (route.name == 'update-user') {
        url = url + '/' + users.value._id;
        method = 'PUT';
        }
    const token = localStorage.getItem('token');
    // submit the user to the backend
    const response = await fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json',
            //add one more line for token authorization 
            Authorization:  `Bearer ${token}`,
        },
        body: JSON.stringify(users.value)
    });
    // convert the response to json
    const json = await response.json();
    // log the json
    console.log(json);
    // alert the user
    alert(JSON.stringify(json));
} 
// a FUNCTION  to GET THE USERS by id from the backend
const getUsers = async function () {
    const token = localStorage.getItem('token');
    // get the booking from the backend
    const response = await fetch('/api/users/' + route.params.id,{
    headers: {
                  Authorization: `Bearer ${token}`, //use the token here
                }
    });
    // convert the response to json
    const json = await response.json();
    // log the json
    //console.log(json);
    if (response.ok) {
    // set the booking
        
        users.value = json.users;
        //alert(JSON.stringify(users.value));
        equipments.value = json.equipments;
        //alert(JSON.stringify( equipments.value));
    }    
    else {
    alert(json.message);
    }
    
};
const deleteUser = async function () {
    const token = localStorage.getItem('token');
    // post the booking to the backend
    const response = await fetch('/api/users/' + users.value._id, {
        method: 'DELETE',
        headers: {
                  Authorization: `Bearer ${token}`, //use the token here
                }
    });
    // convert the response to json
    const json = await response.json();
    // log the json
    console.log(json);
    // alert the user
    alert(JSON.stringify(json));
    // redirect to the home page
    router.push('/');
};
// * Handle page-change event
//  */
const onPageChange = (p) => {
    page.value = p;
    loadAsyncData();
};

/*
 * Handle sort event
 */
const onSort = (column, order) => {
    sortField.value = column?.field;
    sortOrder.value = order;
    loadAsyncData();
};
onMounted (async () =>{
    if (route.params.id){
        await getUsers();
    }
    loadAsyncData();
});
</script>
<template>

  <div class="container-fluid my-5" style="padding-top:20px;">
    <div class="d-flex justify-content-between align-items-center">
      <h5 href="/equipments" class="text-primary">User <span class="text-secondary"> / New</span></h5>
      <button type="submit" class="btn btn-danger mt-2 ms-auto"  v-if="route.name == 'update-user'" v-on:click="deleteUser" >Delete</button>
    </div>
  </div>
  <div class="row">
  <div class="col-md-6">
    <form class="row mb-3 ms-3" v-on:submit.prevent="submitUsers" v-if="route.name != 'user-add'" >
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Email</label>
        <input type="email" class="form-control" id="exampleInputEmail1" v-model="users.email">
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <input type="password" class="form-control" id="exampleInputPassword1" v-model="users.password">
    </div>
    <div class="mb-3">
        <label for="inputName" class="form-label">Name</label>
        <input type="text" class="form-control" id="exampleName" v-model="users.name">
    </div>
    <div class="mb-3">
        <label for="inputContactNumber" class="form-label">Contact number</label>
        <input type="text" class="form-control" id="exampleContactNumber" v-model="users.contactNumber">
    </div>
    <div class="col-12 col-lg-6">
        <label for="inputDepartment" class="form-label">Department</label>
        <select class="form-select" aria-label="Default select example" v-model="users.department">
          <option value="" selected>Dropdown...</option>
          <option value="Computer Science">Computer Science</option>
          <option value="Mathematics">Mathematics</option>
          <option value="Physics">Physics</option>
      </select>
      </div>

      <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Remark</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"  v-model="users.remark"></textarea>
        </div>

        <div class="row mb-3">
        <div class="col-sm-10">
          <div class="form-check">
            <input
              class="form-check-input"
              type="checkbox"
              id="gridCheck1"
              v-model="users.terms"
            />
            <label class="form-check-label" for="gridCheck1">
              Agree to terms and conditions
            </label>
          </div>
        </div>
      </div>
    <div class="row mb-3">
        <div class="col-12 d-flex justify-content-between">
            <button type="submit" class="btn btn-primary" >Save</button>
        </div>
    </div>
</form>
  </div>
<div class="col-md-6">
    <section class="col-md-4">
        <h2 class="text-primary mb-3">Rental History</h2>
        <o-table :data="equipments" :loading="loading" paginated backend-pagination :total="total" :per-page="perPage"
            backend-sorting :default-sort-direction="defaultSortOrder" :default-sort="[sortField, sortOrder]"
            aria-next-label="Next page" aria-previous-label="Previous page" aria-page-label="Page"
            aria-current-label="Current page" @page-change="onPageChange" @sort="onSort">
                <o-table-column v-slot="props" field="name" label="Equipment">
                    <!-- props.row-->
                    {{props.row.name}}
                </o-table-column>

                <o-table-column v-slot="props" field="startTime" label="Rent date and time">
                    <!-- modify time format  -->
                    {{ props.row.rent.startTime ? new Date(props.row.rent.startTime).toLocaleDateString() : 'N/A' }} 
                </o-table-column>
                
                <o-table-column v-slot="props" field="returnTime" label="Return date and time">
                    {{ props.row.rent.returnTime ? new Date(props.row.rent.returnTime).toLocaleDateString() : 'N/A' }}
                </o-table-column>
            </o-table>
    </section>
</div>
  </div>
</template> 