<script setup>
import { ref, onMounted, watch } from "vue" // add watch
import { useRoute } from "vue-router";
import { jwtDecode } from "jwt-decode";
const route = useRoute(); // get id 
const search = ref("");

watch(() => search.value, () => {
    loadAsyncData();
});
const users = ref([]);
const name = ref("");
const total = ref(0);
const loading = ref(false);
const sortField = ref("vote_count");
const sortOrder = ref("desc");
const defaultSortOrder = ref("desc");
const page = ref(1);
const perPage = ref(8);

const loadAsyncData = () => {
    try{
        const params = [
            // "api_key=bb6f51bef07465653c3e553d6ab161a8",
            // "language=en-US",
            // "include_adult=false",
            // "include_video=false",
            // `sort_by=${sortField.value}.${sortOrder.value}`,
            `page=${page.value}`,
        ].join("&");
        // Get the token from local storage    
        const token = localStorage.getItem('token');
        //decode the jtw token 
        const decoded = jwtDecode(token);
        console.log(decoded);
        name.value = `${decoded.first_name} ${decoded.last_name}`;
        fetch(`/api/users?${params}`,{
            headers: {
                    Authorization: `Bearer ${token}`,
                }
        })
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then((result) => {
            perPage.value = result.perPage;
            total.value = result.total;
            users.value = result.users;

            loading.value = false;
        })
    }
    catch(error) {
        console.error('A problem with the fetch operation:', error);
        loading.value = false; 
    }
};
// * Handle page-change event
//  */
const onPageChange = (p) => {
    page.value = p;
    loadAsyncData();
};

/*
 * Handle sort event
 */
const onSort = (column, order) => {
    sortField.value = column?.field;
    sortOrder.value = order;
    loadAsyncData();
};

onMounted(() => {
    loadAsyncData();
});


</script>
<template>
    <div class="container-fluid my-3" style="padding-top:30px; padding-left:30px">
        <div class="d-flex justify-content-between align-items-center">
        <h5 href="/equipments" class="text-primary">User    <span class="text-secondary">/</span></h5>
        <a href="/user/new" class="btn btn-primary">Add</a>
        </div>
    </div>
    <section style="padding: 20px">
        <o-table :data="users" :loading="loading" paginated backend-pagination :total="total" :per-page="perPage"
            backend-sorting :default-sort-direction="defaultSortOrder" :default-sort="[sortField, sortOrder]"
            aria-next-label="Next page" aria-previous-label="Previous page" aria-page-label="Page"
            aria-current-label="Current page" @page-change="onPageChange" @sort="onSort">
            <o-table-column v-slot="props" field="name" label="User name" sortable>
                {{ props.row.name }}

            </o-table-column>
            <o-table-column v-slot="props" field="email" label="Email" sortable>
                {{ props.row.email }}
            </o-table-column>
            <o-table-column v-slot="props" field="contactNumber" label="Contact">
                {{ props.row.contactNumber }}
            </o-table-column>
            <o-table-column v-slot="props" field="name" label="Action">
                <a :href="`user/edit/${props.row._id}`" class="btn btn-secondary" style="width:100px;">Edit</a>
            </o-table-column>
        </o-table>
        
    </section>
    
</template>