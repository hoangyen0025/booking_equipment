<script setup>
import { ref, onMounted, computed, watch } from 'vue';
import { useRoute, useRouter } from "vue-router";
const route = useRoute(); // get id 
const router = useRouter(); //transfer a page 
const equipments = ref({
    name: '',
    location: '',
    description: '',
    image: '',
    contactPerson: '',
    color: '0000FF',
    highlight: false,
});
// a FUNCTION  to GET THE EQUIPMENT from the backend
const getEquipments = async function () {
    const token = localStorage.getItem('token');

    // get the booking from the backend
    const response = await fetch('/api/equipments/' + route.params.id,{
      headers: {
                  Authorization: `Bearer ${token}`, //use the token here
                }
    });
    // convert the response to json
    const json = await response.json();
    if (response.ok){
       // log the json
      equipments.value = json.equipment;
    }
    else {
    alert(json.message);
    }
};

const submitEquipments = async function () {
      var url = '/api/equipments';
      var method = 'POST';
    // post the booking to the backend
        if (route.name == 'update-equipment') {
        url = url + '/' + equipments.value._id;
        method = 'PUT';
    }

    // submit the booking to the backend
    const response = await fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(equipments.value)
    });
    // convert the response to json
    const json = await response.json();
    // log the json
    console.log(json);
    // alert the user
    alert(JSON.stringify(json));
    router.push('/equipments')
} 

const deleteEquipment = async function () {
    // post the booking to the backend
    const response = await fetch('/api/equipments/' + equipments.value._id, {
        method: 'DELETE'
    });
    // convert the response to json
    const json = await response.json();
    // log the json
    console.log(json);
    // alert the user
    //alert(JSON.stringify(json));
    // redirect to the home page
    router.push('/');
};
onMounted (async () =>{
    if (route.params.id){
        await getEquipments();
    } 
    if (response.ok) {
    // set the booking
    booking.value = json;
  } else {
    alert(json.message);
  } 
});

</script>
<template>
    <div class="container-fluid my-5" style="padding-top:20px;">
    <div class="d-flex justify-content-between align-items-center">
      <h5 href="/equipments" class="text-primary">Equipments /<span class="text-secondary"> Edit</span></h5>
    </div>
    </div>

  <form class="row mb-3 ms-3" v-on:submit.prevent="submitEquipments" v-if="route.name != 'equipment-add'">
    <div class="row mb-3">

      <div class="col-12 col-lg-6 ">
        <label for="inputName" class="form-label">Name</label>
        <input type="text" class="form-control" placeholder="" aria-label="First name" v-model="equipments.name">
      </div>

      <div class="col-12 col-lg-6">
        <label for="inputLocation" class="form-label">Location</label>
        <select class="form-select" aria-label="Default select example"  v-model="equipments.location">
          <option value="" selected>Select location</option>
          <option value="FSC801C">FSC801C</option>
          <option value="FSC801D">FSC801D</option>
          <option value="FSC901E">FSC901E</option>
      </select>
      </div>

    </div>
    
<!-- Description box  -->
    <div class="row mb-3">
      <label for="exampleFormControlDescription" class="form-label">Description</label>
      <textarea class="form-control" id="exampleFormControlDescription" rows="3" v-model = "equipments.description"></textarea>
    </div>

<!-- Img, URL, color -->
  <div class="row mb-3">

    <div class="col-12 col-lg-6">
      <label for="inputImage" class="form-label">Image</label>
      <input type="text" class="form-control" id="inputImage" placeholder="" aria-label="Image" v-model = "equipments.image">
    </div>

    <div class="col-12 col-lg-4">
      <label for="inputContactPerson" class="form-label">Contact Person</label>
      <input type="text" class="form-control" id="inputContactPerson" placeholder="" aria-label="Contact person"  v-model="equipments.contactPerson">
    </div>
    <div class="col-12 col-lg-2">
      <label for="inputColor" class="form-label">Color</label>
      <input type="color" id="colorPicker" class="form-control form-control-color"  v-model="color" value="#0000FF" title="Choose your color" style="width:100%">
    </div>
  </div>

  <div class="row mb-3">
    <div class="col">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" id="gridCheck1"  v-model="equipments.highlight">
            <label class="form-check-label" for="gridCheck1">
                Highlight
            </label>
        </div>
    </div>
</div>

<div class="row mb-3">
    <div class="col-12 d-flex justify-content-between">
        <button type="submit" class="btn btn-primary mt-2">Save</button>
        <button type="submit" class="btn btn-danger mt-2 ms-auto" v-if="route.name == 'update-equipment'" v-on:click="deleteEquipment">Delete</button>
    </div>
</div>
</form>
</template>