<script setup>
import { ref, onMounted, computed, watch } from 'vue'
import { useRoute } from "vue-router";
import { jwtDecode } from "jwt-decode";
const router = useRoute(); //transfer a page 
const users = ref({});
const equipments = ref({
    email: '',
    password: '',
    name: '',
    contactNumber: '',
    department: '',
    remark: '',
});

const credentials=ref({
  startTime: '',
  returnTime: '',
});
const token = ref('');
const rent = ref([]);
const total = ref(0);
const loading = ref(false);
const sortField = ref("vote_count");
const sortOrder = ref("desc");
const defaultSortOrder = ref("desc");
const page = ref(1);
const perPage = ref(8);

const loadAsyncData = () => {
    try{
        const params = [
            // "api_key=bb6f51bef07465653c3e553d6ab161a8",
            // "language=en-US",
            // "include_adult=false",
            // "include_video=false",
            // `sort_by=${sortField.value}.${sortOrder.value}`,
            `page=${page.value}`,
        ].join("&");
        // Get the token from local storage    
        const token = localStorage.getItem('token');
        //decode the jtw token 
        const decoded = jwtDecode(token);
        console.log(decoded);
        name.value = `${decoded.first_name} ${decoded.last_name}`;
        fetch(`/api/equipments?${params}`,{
            headers: {
                    Authorization: `Bearer ${token}`,
                }
        })
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then((result) => {
            perPage.value = result.perPage;
            total.value = result.total;
            users.value = result.users;

            loading.value = false;
        })
    }
    catch(error) {
        console.error('A problem with the fetch operation:', error);
        loading.value = false; 
    }
};
// a FUNCTION  to GET THE EQUIPMENT BY ID from the backend
const getEquipments = async function () {
      // Get the token from local storage 
    const token = localStorage.getItem('token');
    // get the booking from the backend
    const response = await fetch('/api/equipments/' + router.params.id,{
      headers: {
                  Authorization: `Bearer ${token}`, //use the token here
                }
    });
    // convert the response to json
    const json = await response.json();
    if (response.ok){
      equipments.value = json.equipment;
      rent.value = json.equipment.rent 
      //alert(JSON.stringify(rent.value)) //to get user who rent it
    }   
    else {
      alert(json.message);
    }
};
const submitRent = async function() {
        // Get the token from local storage 
        const token = localStorage.getItem('token');
        try{
        // post the rental to the backend 
        const response = await fetch(`/api/equipments/${equipments.value._id}/rent`,
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json', 
                Authorization: `Bearer ${token}`,  //use the token here
            },
            body: JSON.stringify(credentials.value)
        });
        // convert the response to json
        const json = await response.json();
        // log the json
        console.log(json);
         // alert the user
        alert(`Rental submmitted: Rental from ${credentials.value.startTime} to ${credentials.value.returnTime}`);
        // alert the user
        //alert(JSON.stringify(json));
        //router.push('/equipments');
}
  catch(error){
    console.error('A problem with the fetch operation:', error);
  }
}
//instead of delete, should use PUT method to update
const deleteRent = async function (index, colindex){
  const token = localStorage.getItem('token');
  //post equipment to the backend
  //if (colindex != 3) return;
  //alert(JSON.stringify(equipments.value.rent.splice(index,1)));
  equipments.value.rent.splice(index,1);
  try {
    const response = await fetch(`/api/equipments/${equipments.value._id}`,
        {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json', 
                Authorization: `Bearer ${token}`,  //use the token here
            },
            body: JSON.stringify({rent: equipments.value.rent})
        });
         // convert the response to json
        const json = await response.json();
        // log the json
        console.log(json);
  }
  catch (error){
    console.error('detele unsuccessfully:', error);
  }
}
const onPageChange = (p) => {
    page.value = p;
    loadAsyncData();
};

/*
 * Handle sort event
 */
const onSort = (column, order) => {
    sortField.value = column?.field;
    sortOrder.value = order;
    loadAsyncData();
};
//////
onMounted(async () => {
    // if there is an id in the route
    if (router.params.id) {
        await getEquipments();
    }
    token.value = localStorage.getItem("token");
    if (token.value){
      users.value = jwtDecode(token.value); //check if user or admin
    }
    loadAsyncData();
});

</script>

<template>
  <div class="container-fluid my-5" style="padding-top: 20px">
    <div class="d-flex justify-content-between align-items-center">
      <h5 class="text-primary">Equipments / <span class="text-secondary">{{equipments.name}}@{{equipments.location}}</span></h5>
    </div>
  </div>

      <div class="container-fluid my-3">
        <div class="row">
          <div class="col-md-6">
            <div class="card mb-3">
              <a href="">
                <img v-bind:src="equipments.image" class="card-img-top" alt="">
              </a>
              <div class="card-body">
                <h5 class="card-title">{{equipments.name}}</h5>
                <p class="card-text">{{equipments.description}}</p>
                <!-- <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p> -->
              </div>
            </div>
        </div>
          <!-- only after login (as user) can see the rental box  -->
          <div class="col-md-5">
            <form v-on:submit.prevent="submitRent" v-if="token && !users.terms">
            <div class="card mx-5" style="width: 100%">
                <div class="card-body">
                  <h5 class="card-title">Rental application</h5>
                  <div class="col"> 
                    <label for="startTime">Start (date and time)</label>
                    <input type="datetime-local" class="form-control mt-2" id="startTime" name="startTime" v-model="credentials.startTime">
                  </div>
                  <div class="col">
                    <label for="returnTime">Return (date and time)</label>
                    <input type="datetime-local" class="form-control mt-2" id="returnTime" name="returnTime" v-model="credentials.returnTime">
                  </div>
                  <br>
                  <div>
                    <button type="submit" class="btn btn-primary">Rent</button>
                  </div>
                </div>
            </div>
            </form>
          </div>
          </div>
        </div>
    <section v-if = "users.terms">
    <h2 class="text-primary mb-3">Rental History</h2>
    <o-table :data="rent" :loading="loading" paginated backend-pagination :total="total" :per-page="perPage"
            backend-sorting :default-sort-direction="defaultSortOrder" :default-sort="[sortField, sortOrder]"
            aria-next-label="Next page" aria-previous-label="Previous page" aria-page-label="Page"
            aria-current-label="Current page" @page-change="onPageChange" @sort="onSort"@cell-click="deleteRent">
            <o-table-column v-slot="props" field="name" label="User name">
                <!-- why it props.row here instead -->
                {{props.row.name}}
            </o-table-column>

            <o-table-column v-slot="props" field="startTime" label="Rent date and time">
                <!-- modify time format  -->
                {{ props.row.startTime ? new Date(props.row.startTime).toLocaleDateString() : 'N/A' }} 
            </o-table-column>
            <o-table-column v-slot="props" field="returnTime" label="Return date and time">
                {{ props.row.returnTime ? new Date(props.row.returnTime).toLocaleDateString() : 'N/A' }}
            </o-table-column>
            <o-table-column fielf="action" label="Action">
              <button type="button" class="btn btn-danger">Delete</button>
            </o-table-column>
        </o-table>
</section>
</template>