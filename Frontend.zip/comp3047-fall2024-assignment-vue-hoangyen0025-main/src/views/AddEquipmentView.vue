<script setup>
import { ref, onMounted, computed, watch } from 'vue'
import { useRoute, useRouter } from "vue-router";
const router = useRouter(); //transfer a page 
const equipments = ref({
    name: '',
    location: '',
    description: '',
    image: '',
    contactPerson: '',
    color: '0000FF',
    highlight: false,
});
// a FUNCTION  to SUBMIT THE EQUIPMENT to the backend
    const submitEquipments = async function() {
        // post the booking to the backend
        const response = await fetch('/api/equipments', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(equipments.value)
        });
        // convert the response to json
        const json = await response.json();
        // log the json
        console.log(json);
        // alert the user
        alert(JSON.stringify(json));
        router.push('/equipments');
}

</script>
<template>

  <div class="container-fluid my-5" style="padding-top:20px;">
    <div class="d-flex justify-content-between align-items-center">
      <h5 href="/equipments" class="text-primary">Equipments<span class="text-secondary"> / Add</span></h5>
    </div>
  </div>
  <form class="row mb-3 ms-3" v-on:submit.prevent="submitEquipments">
    <div class="row mb-3">

      <div class="col-12 col-lg-6 ">
        <label for="inputName" class="form-label">Name</label>
        <input type="text" class="form-control" placeholder="" aria-label="First name" v-model="equipments.name">
      </div>

      <div class="col-12 col-lg-6">
        <label for="inputLocation" class="form-label">Location</label>
        <select class="form-select" aria-label="Default select example" v-model="equipments.location">
          <option value="" selected>Select location</option>
          <option value="FSC801C">FSC801C</option>
          <option value="FSC801D">FSC801D</option>
          <option value="FSC901E">FSC901E</option>
      </select>
      </div>
    </div>
    
<!-- Description box  -->
    <div class="row mb-3">
      <label for="exampleFormControlDescription" class="form-label">Description</label>
      <textarea class="form-control" id="exampleFormControlDescription" rows="3" v-model = "equipments.description"></textarea>
    </div>
<!-- Img, URL, color -->

  <div class="row mb-3">

    <div class="col-12 col-lg-6">
      <label for="inputImage" class="form-label">Image</label>
      <input type="text" class="form-control" id="inputImage" placeholder="" aria-label="Image" v-model = "equipments.image">
    </div>

    <div class="col-12 col-lg-4">
      <label for="inputContactPerson" class="form-label">Contact Person</label>
      <input type="text" class="form-control" id="inputContactPerson" placeholder="" aria-label="Contact person"  v-model="equipments.contactPerson">
    </div>
    <div class="col-12 col-lg-2">
      <label for="inputColor" class="form-label">Color</label>
      <input type="color" id="colorPicker" class="form-control form-control-color"  v-model="color" value="#0000FF" title="Choose your color" style="width:100%">
    </div>
  </div>

  <div class="row mb-3">
    <div class="col">
        <div class="form-check">
          <!--  v-model="equipments.highlight" -->
            <input class="form-check-input" type="checkbox" id="gridCheck1" v-model="equipments.highlight">
            <label class="form-check-label" for="gridCheck1">
                Highlight
            </label>
        </div>
    </div>
</div>

  <div class="row mb-3">
    <div class="col-12 col-lg-12">
      <button type="submit" class="btn btn-primary mt-2">Save</button>
    </div>
  </div>
</form>
   
</template>

