<script setup>
import { ref, onMounted, useSSRContext} from 'vue';
import { useRoute } from "vue-router";
import { jwtDecode } from "jwt-decode";
const route = useRoute(); // get id 
const token = ref(localStorage.getItem('token'));
const users = ref({});

const logout = async function() {
  // Get the token from local storage    
  const token = localStorage.getItem('token');
  
  try {
      // Send a request to the endpoint with the token in the Authorization header
      var response = await fetch("/api/logout", {
          method: "POST",
          headers: {
              Authorization: `Bearer ${token}`,
          }
      });

      if (!response.ok) {
          throw new Error(response.statusText);
      }
      
      localStorage.removeItem('token');
      // Reset email and password fields
      //document.getElementById('emailInput').value = ''; // Replace with your email input's ID
      //document.getElementById('passwordInput').value = ''; // Replace with your password input's ID
      alert("Logout Successfully.")
      //location.reload();
      location.assign("/");
  } catch (error) {
      console.error("Logout error:", error);
      alert("An error occurred during logout. Please try again.");
  }
}
onMounted(() => { //when the page is reloaded the query inside also get reloaded 
  token.value = localStorage.getItem('token');
  if (token.value){
      users.value = jwtDecode(token.value); //check if user or admin
    }
})
</script>


<template>
  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Equipment Rental</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/equipments">Equipments</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/users" v-if="users.terms">Users</a>
        </li>
        
      </ul>
      <!-- SEARCH BOX    -->
       <form class="d-flex" v-on:submit.prevent="searchSubmission" >
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
      <form 
        action="/login" method="GET" v-if="!token">
        <button type="submit" class="btn btn-primary">Login</button>
      </form>
      <form action = "/logout" method v-if ="token" >
        <button type="button" class="btn btn-primary my-4" @click="logout">Log Out</button>
      </form>
    </div>
  </div>
</nav>

  </header>

  <RouterView />
</template>

<style scoped>

</style>
